from main import Addressee, Attachment, Email
